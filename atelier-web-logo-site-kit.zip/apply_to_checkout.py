#!/usr/bin/env python3
"""Atelier Web logo installer: run at the root of an existing djms66.github.io checkout."""
from pathlib import Path
import re, shutil, sys
root=Path.cwd()
if not (root/'build.py').is_file() or not (root/'CNAME').is_file():
    sys.exit('Erreur: executer depuis la racine de djms66.github.io (build.py et CNAME requis).')
assets=Path(__file__).resolve().parent
# Work on a branch created by the user; do not modify a live main checkout.
import subprocess
p=subprocess.run(['git','branch','--show-current'],capture_output=True,text=True)
if p.returncode or p.stdout.strip() in ('main','master',''):
    sys.exit('Protection: creez puis selectionnez une branche de travail avant de lancer ce script.')
shutil.copy2(assets/'logo.svg',root/'logo.svg')
shutil.copy2(assets/'apple-touch-icon.png',root/'apple-touch-icon.png')
shutil.copytree(assets/'press',root/'press',dirs_exist_ok=True)
# Existing pages embed the OLD symbol inline; replace ONLY those inline header marks.
inline=re.compile(r'<svg class="logo"\b[^>]*>.*?</svg>',re.S)
for path in root.rglob('*.html'):
    if '.git' in path.parts or 'press' in path.parts:
        continue
    old=path.read_text(encoding='utf-8')
    new,n=inline.subn('<img class="logo" src="/logo.svg" alt="" width="28" height="28">',old)
    if n:
        # old CSS sets SVG fill; remove fill so replacement image displays naturally
        path.write_text(new,encoding='utf-8')
        print('Logo remplacé dans',path.relative_to(root),n)
# Maintain the generator: future runs of build.py should not bring back the old mark.
build=root/'build.py'
s=build.read_text(encoding='utf-8')
old='f\'<svg class="logo" viewBox="0 0 3070 2665" aria-hidden="true"><path fill-rule="evenodd" d="{LOGO_PATH}"/></svg>{home_label}</a>\')'
new='f\'<img class="logo" src="/logo.svg" alt="" width="28" height="28">{home_label}</a>\')'
if old in s:
    build.write_text(s.replace(old,new),encoding='utf-8')
    print('Générateur build.py adapté')
else:
    print('Attention : modèle de logo introuvable dans build.py. Vérifier le générateur avant reconstruction.')
print('Préparation terminée sur la branche',p.stdout.strip())
print('Vérifiez localement les pages puis décidez vous-même de la fusion et de la publication.')
