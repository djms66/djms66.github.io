KIT ATELIER WEB — nouveau logo + page presse bilingue

Ce ZIP ne remplace pas votre dépôt et ne publie rien à lui seul.

1. Sur votre Mac, obtenez un clone local de djms66/djms66.github.io.
2. Dans Terminal depuis ce dossier: git switch -c update-atelier-web-logo-press
3. Décompressez ce ZIP dans un dossier extérieur au clone.
4. Exécutez: python3 /chemin/vers/le/kit/apply_to_checkout.py
   (le script doit être lancé depuis la racine du clone)
5. Contrôlez les modifications avec git diff et vérifiez le rendu et les vidéos en local.
6. Faites un commit et poussez la branche seulement après vérification.
7. Fusionnez dans main uniquement après approbation : GitHub Pages publiera alors les modifications.

Ce kit contient : logo.svg, apple-touch-icon.png, press/index.html, press/assets/*.mp4 et *.jpg.
Le logo de la page presse et les en-têtes du site pointent vers /logo.svg.
IMPORTANT: l'icône iOS Safari Apple peut disposer d'un fond transparent ; à vérifier sur l'appareil.
