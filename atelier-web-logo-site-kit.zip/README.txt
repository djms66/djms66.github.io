ATELIER WEB — PRESS KIT / GITHUB PAGES

This package is designed to be installed in the existing site repository
https://github.com/djms66/djms66.github.io

Put the entire 'press' folder into the repository root.
Do NOT replace the existing index.html, CNAME, logo, or other pages.

Target URL after publication, assuming the configured custom domain works:
https://atelier-web.danielstreng.fr/press/
English: ?lang=en
French: ?lang=fr

Contains:
press/index.html          responsive bilingual page
press/assets/demo-en.mp4 English preview (29 s)
press/assets/demo-fr.mp4 French product film (79 s)
press/assets/preview-en.jpg and preview-fr.jpg real video stills

The two images are real frames extracted from the supplied demonstration videos.
Only share publicly after reviewing the entire material for confidential information.
The feature list is intentionally conservative; it does not promise unverified export or publishing capabilities.
